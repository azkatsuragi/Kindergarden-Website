<?php
//Set Db parameters

$servername = "localhost";
$username = "db_smart_user";
$password = "VVision123";
$dbname = "db_smart";

//Create DB Connection
$con=mysqli_connect($servername,$username,$password,$dbname);
//Create Db Connection

?>